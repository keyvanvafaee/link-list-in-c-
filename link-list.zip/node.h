#include<iostream>
using namespace std;

class node
{

private:

int data ;
node * link;


public:

node ()
{
data =0;
link =0;

}


void setdata( int item)
 {
	data = item;
 }


void setlink(node * m)

 {
	link = m;

 }

int getdata()
{
return data ;
}

node * getlink()
{
return link;
}


};
