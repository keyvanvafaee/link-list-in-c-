#include"node.h"

class link_list
{

private:
node * first;
node * last ;
node * stemp;



public:

link_list()
{
first = last =0;

stemp=0; 
 
}

void add2list(int item )
  {

	node * temp = new node;
	temp->setdata(item);

	if (first)
		{
			last->setlink(temp);
			last = temp;
		}

	else 
	{
		stemp = first = last =  temp;
	}


  }


void display_list()
{

node * temp = new node;
temp = first;

while (temp !=0 )
{

 cout << temp->getdata()<< endl;;
 temp= temp->getlink();

}


}


void del2list2()
	{
		node * temp = first;

		node * temp2 = first;

		while ( temp->getlink() !=0 )
			{

			temp= temp->getlink();
			temp2 -> setlink(temp->getlink());
						
			temp2= temp;

	

			}
	
	}

void add2list2(int item )
	{

	

	

			node * temp = new node;

			temp->setdata(item);

			temp->setlink(stemp->getlink());
			
			stemp->setlink(temp);

			temp = temp->getlink();

			stemp = temp;
			
		

	}

void swap(node * a , node * b) // we swap datas between nodes 
{

int temp=0;
int temp2=0;

        
                temp = a->getdata();
                
                temp2= b->getdata();
                                
                b->setdata(temp);   
                                   
                a->setdata(temp2);
                
                
}

void sort()
{
node * temp;
node * temp2;
for ( temp = first; temp!=0; temp=temp->getlink())
 for ( temp2 = first ; temp2 !=0; temp2=temp2->getlink())
  if ( temp2->getdata() >= temp->getdata())
    {
    swap(temp2,temp);
    
    
    }

}

};

