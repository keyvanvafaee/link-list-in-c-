/*
 *
 *
author : keyvan V 
SIMPLE LINK LIST IMPLEMENTATION IN C++ 

add2list() -> add nodes to linklist 
display() -> show link list data's
del2list2() -> delete all even nodes
addd2list2() -> add nodes between odd nods
sort () -> sorting list list :)
swap() -> swap two node's data

*
*
*/

#include"link.h"

int main()
{

link_list * l1 = new link_list;

l1->add2list(211);

l1 -> add2list(-23);

l1->add2list(5);

l1->add2list(7);

l1 -> add2list(9);

l1->add2list(11);

//l1->del2list2();

l1->add2list2(110212);
l1->add2list2(-214);
l1->add2list2(-21);
l1->add2list2(80);
l1->add2list2(1900);
l1->sort();

l1->display_list();


}
